import logo from '../assets/logo.png'
import ufs from '../assets/ufs.png'

export const Photo = {
    logo:logo,
    ufs:ufs,
    
};

export default Photo