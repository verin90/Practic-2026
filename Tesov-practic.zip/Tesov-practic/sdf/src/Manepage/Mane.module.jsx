import { useState } from 'react'
import classes from './Mane.module.css'


function Mane() {
  const [count, setCount] = useState(0)

  return (
    <>
    <main>
        <div className={classes.component}>
            <div className={classes.comp1}>
                <div className={classes.text}>
                    <p className={classes.p1}>УЧАСТВУЙ В МИРОВОМ</p>
                    <div className={classes.p_big}>
                        <p className={classes.p2}>ПЕРВЕНСТВЕ</p>
                        <p className={classes.p3}>#USF</p>
                    </div>
                </div>
                <div className={classes.button_text}>
                    <p className={classes.p_button}>«Grand-Prix»</p>
                    <p className={classes.p2_button}>$ 1 000 000</p>
                    <button>ЗАЯВКА НА УЧАСТИЕ</button>
                </div>
            </div>
            <div className={classes.comp2}>

            </div>
        </div>
    </main>
    </>
  )
}

export default Mane